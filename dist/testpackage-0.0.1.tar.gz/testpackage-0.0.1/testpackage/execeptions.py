class ObjectNotFound(Exception):
    """An exception risen when ab expected onject is not found"""

class InvaildOperation(Exception):
    """Ab exception risen when an attemped opration does not make sense"""
